<?php
class SNI extends ActiveRecord\Model {
	static $table_name = 'Nivel_SNI';
	static $has_one = array(
	);
	static $has_many = array(
	);
	static $belongs_to = array(
	);
	
	static $alias_attribute = array(
	);
}
?>