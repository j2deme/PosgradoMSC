X.X / not released
==================

  * added history.md


1.1.0 / 2012-09-16
==================

  * Updated composer.json
  * Added better error messaging for failed readme generation
  * Fixed readme typos
  * Added static helpers `today()`, `tomorrow()`, `yesterday()`
  * Simplified `now()` code

1.0.1 / 2012-09-10
==================

  * Added travis-ci.org

1.0.0 / 2012-09-10
==================

  * Initial release
