# nvd3 - v0.0.1

A reusable chart library for d3.JS by Bob Monteverde of Novus Partners.


Currently in an early stage of development, but will be a very active project.  It may change quite a bit from its current state, but will always try to follow the style in which d3.js was done.

You can also check out the [examples page](http://nvd3.com/ghpages/examples.html)

