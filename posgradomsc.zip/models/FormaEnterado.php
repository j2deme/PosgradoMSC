<?php
class FormaEnterado extends ActiveRecord\Model {
	static $table_name = 'Forma_enterado';
	static $has_one = array(		
	);
	static $has_many = array(
	);
	static $belongs_to = array(
	);
	
	static $alias_attribute = array(
	);
}
?>