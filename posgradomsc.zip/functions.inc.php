<?php
function humanize_gump($errors, $dictionary = array (),$html = TRUE) {
	$response = array();
	$message = function($regla,$campo) {
		$campo = (isset($dictionary[$campo])) ? $dictionary[$campo] : $campo;
		$messages = array(
			'validate_required' => "El valor del campo $campo es obligatorio, y no debe ser vacío.",
			'validate_valid_email' => "El valor del campo $campo debe ser un email válido.",
			'validate_max_len' => "La longitud del campo $campo es mayor a la longitud máxima.",
			'validate_min_len' => "La longitud del campo $campo es menor a la longitud mínima.",
			'validate_exact_len' => "La longitud del campo $campo no es la esperada.",
			'validate_alpha' => "El valor del campo $campo solo admite caracteres del alfabeto.",
			'validate_alpha_numeric' => "El valor del campo $campo solo admite caracteres alfanuméricos.",
			'validate_alpha_dash' => "El valor del campo $campo solo admite caracteres alfanuméricos y guiones.",
			'validate_numeric' => "El valor del campo $campo debe ser un número.",
			'validate_integer' => "El valor del campo $campo debe ser un número entero.",
			'validate_boolean' => "El valor del campo $campo debe ser un valor boolean.",
			'validate_float' => "El valor del campo $campo debe ser un número decimal.",
			'validate_valid_url' => "El valor del campo $campo debe ser una URL válida.",
			'validate_url_exists' => "El valor del campo $campo debe ser una URL existente.",
			'validate_valid_ip' => "El valor del campo $campo debe ser una IP válida.",
			'validate_valid_cc' => "El valor del campo $campo debe ser un número de tarjeta de crédito válido.",
			'validate_valid_name' => "El valor del campo $campo debe ser un nombre personal válido."
		);
		return $messages[$regla];
	};
	$list = "<ul>";
	foreach ($errors as $e) {
		$campo = $e['field'];
		$regla = $e['rule'];
		$response[$campo][] = $m = $messages($regla,$campo);
		$list .= "<li>" . $m . "</li>";
	}
	$list .= "</ul>";
	if ($html) {
	#XXX [06/07/12] Problema de codificación al devolver html resuelto con |raw en Twig
		return $list;
	} else {
		return $messages;
	}
}

function sendMail($to, $subject, $body, $from, $alias) {
	$mail = new PHPMailer();
	$mail -> Mailer = "smtp";
	$mail -> Host = "smtp.gmail.com";
	$mail -> SMTPAuth = TRUE;
	$mail -> Username = "posgradomsc@gmail.com";
	$mail -> Password = "posgradomsc2012";
	$mail -> From = $from;
	$mail -> FromName = $alias;
	$mail -> Subject = $subject;
	$email = $to;
	$body = $body;
	$mail -> Body = $body;
	$mail -> AltBody = strip_tags($body);
	$mail -> Timeout = 20;
	if (is_array($email)) {
		foreach ($email as $e) {
			$mail -> AddAddress($e);
		}
	} else {
		$mail -> AddAddress($email);
	}
	$status = $mail -> Send();
	$tries = 1;
	while ((!$status) && ($tries < 5) && ($mail -> ErrorInfo != "SMTP Error: Data not accepted")) {
		sleep(5);
		$status = $mail -> Send();
		$tries++;
	}

	if ($mail -> ErrorInfo == "SMTP Error: Data not accepted") {
		$status = FALSE;
	}

	return $status;
}

function isAllowed($roles,$redirect = TRUE,$permisos = array()){
	$app = Slim::getInstance();
	$id = $app -> getCookie('userId');
	$login = FALSE;
	if(isset($id)) {
		$user = Usuario::find($id,array('include' => array('personal','ur')));
		$userRol = $user->ur[0]->rol->nombre;
		if(is_array($roles)){
			if(!in_array($roles,$userRol)){
				$login = TRUE;
			}
		} elseif(is_string($roles)) {
			if($userRol != $roles){
				$login = TRUE;
			}
		} else {
			$login = TRUE;
		}
		
		return $user; 
	} else {
		$login = TRUE;
	}
	if($redirect && $login){
		$app->redirect($app->urlFor('home'));
	}
}
?>