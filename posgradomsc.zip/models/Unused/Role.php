<?php
class Role extends ActiveRecord\Model {
	
}
?>