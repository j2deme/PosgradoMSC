/* Use this script if you need to support IE 7 and IE 6. */

window.onload = function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'custom-icomoon\'">' + entity + '</span>' + html;
	}
	var icons = {
			'icon-seven-segment' : '&#x21;',
			'icon-seven-segment-2' : '&#x22;',
			'icon-seven-segment-3' : '&#x23;',
			'icon-seven-segment-4' : '&#x24;',
			'icon-seven-segment-5' : '&#x25;',
			'icon-seven-segment-6' : '&#x26;',
			'icon-seven-segment-7' : '&#x27;',
			'icon-seven-segment-8' : '&#x28;',
			'icon-seven-segment-9' : '&#x29;',
			'icon-seven-segment-10' : '&#x2a;',
			'icon-bluetooth' : '&#x2b;',
			'icon-libreoffice' : '&#x2c;',
			'icon-file-pdf' : '&#x2d;',
			'icon-file-openoffice' : '&#x2e;',
			'icon-file-word' : '&#x2f;',
			'icon-file-excel' : '&#x30;',
			'icon-file-powerpoint' : '&#x31;',
			'icon-file-zip' : '&#x32;',
			'icon-file-xml' : '&#x33;',
			'icon-file-css' : '&#x34;',
			'icon-embed' : '&#x35;',
			'icon-none' : '&#x36;',
			'icon-sunrise' : '&#x37;',
			'icon-sun' : '&#x38;',
			'icon-moon' : '&#x39;',
			'icon-sun-2' : '&#x3a;',
			'icon-windy' : '&#x3b;',
			'icon-wind' : '&#x3c;',
			'icon-snowflake' : '&#x3d;',
			'icon-cloudy' : '&#x3e;',
			'icon-cloud' : '&#x3f;',
			'icon-weather' : '&#x40;',
			'icon-weather-2' : '&#x41;',
			'icon-weather-3' : '&#x42;',
			'icon-lines' : '&#x43;',
			'icon-cloud-2' : '&#x44;',
			'icon-sun-3' : '&#x45;',
			'icon-lightning' : '&#x46;',
			'icon-cloudy-2' : '&#x47;',
			'icon-lightning-2' : '&#x48;',
			'icon-weather-4' : '&#x49;',
			'icon-cloud-3' : '&#x4a;',
			'icon-cloudy-3' : '&#x4b;',
			'icon-weather-5' : '&#x4c;',
			'icon-snowy' : '&#x4d;',
			'icon-snowy-2' : '&#x4e;',
			'icon-windy-2' : '&#x4f;',
			'icon-snowy-3' : '&#x50;',
			'icon-snowy-4' : '&#x51;',
			'icon-windy-3' : '&#x52;',
			'icon-snowy-5' : '&#x53;',
			'icon-rainy' : '&#x54;',
			'icon-windy-4' : '&#x55;',
			'icon-rainy-2' : '&#x56;',
			'icon-windy-5' : '&#x57;',
			'icon-lightning-3' : '&#x58;',
			'icon-rainy-3' : '&#x59;',
			'icon-cloud-4' : '&#x5a;',
			'icon-rainy-4' : '&#x5b;',
			'icon-cloud-5' : '&#x5c;',
			'icon-lightning-4' : '&#x5d;',
			'icon-cloudy-4' : '&#x5e;',
			'icon-lightning-5' : '&#x5f;',
			'icon-moon-2' : '&#x60;',
			'icon-thermometer' : '&#x61;',
			'icon-compass' : '&#x62;',
			'icon-Celsius' : '&#x63;',
			'icon-Fahrenheit' : '&#x64;'
		},
		els = document.getElementsByTagName('*'),
		i, attr, html, c, el;
	for (i = 0; i < els.length; i += 1) {
		el = els[i];
		attr = el.getAttribute('data-icon');
		if (attr) {
			addIcon(el, attr);
		}
		c = el.className;
		c = c.match(/icon-[^\s'"]+/);
		if (c) {
			addIcon(el, icons[c[0]]);
		}
	}
};