<?php
class PROMEP extends ActiveRecord\Model {
	static $table_name = 'Estatus_PROMEP';
	static $has_one = array(
	);
	static $has_many = array(
	);
	static $belongs_to = array(
	);
	
	static $alias_attribute = array(
	);
}
?>