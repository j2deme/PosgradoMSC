<?php
    header('Location: http://www.lastcraft.com:80/test/network_confirm.php?r=rrr');
?><html>
    <head><title>Redirection test</title></head>
    <body>This is a test page for the SimpleTest PHP unit tester</body>
</html>