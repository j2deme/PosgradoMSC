<?php
    sleep(2);
?><html>
    <head><title>Slow page</title></head>
    <body>This page takes at least two seconds</body>
</html>